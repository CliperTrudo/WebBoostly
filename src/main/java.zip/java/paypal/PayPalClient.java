package paypal;

import com.paypal.core.PayPalEnvironment;
import com.paypal.core.PayPalHttpClient;

public class PayPalClient {
    private static final String CLIENT_ID     = System.getenv("PAYPAL_CLIENT_ID	");
    private static final String CLIENT_SECRET = System.getenv("PAYPAL_CLIENT_SECRET");
    private static final String MODE          = System.getenv().getOrDefault("PAYPAL_MODE", "sandbox");

    private PayPalHttpClient client;

    public PayPalClient() {
        PayPalEnvironment env = "live".equalsIgnoreCase(MODE)
            ? new PayPalEnvironment.Live(CLIENT_ID, CLIENT_SECRET)
            : new PayPalEnvironment.Sandbox(CLIENT_ID, CLIENT_SECRET);

        this.client = new PayPalHttpClient(env);
    }

    public PayPalHttpClient client() {
        return client;
    }
}
