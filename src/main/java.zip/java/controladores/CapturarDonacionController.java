package controladores;

import servicios.PayPalServicio;
import com.paypal.orders.Order;
import org.json.JSONObject;

import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.BufferedReader;
import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Instant;

/**
 * Servlet que:
 *  1) Captura una orden en PayPal (capture).
 *  2) Actualiza el registro de donación en tu API externa.
 *  3) Responde al cliente con éxito.
 */
@WebServlet("/donar/capturar")
public class CapturarDonacionController extends HttpServlet {

    private PayPalServicio paypalServicio;
    private HttpClient httpClient;

    @Override
    public void init() {
        // Lee credenciales de entorno
        String clientId     = System.getenv("PAYPAL_CLIENT_ID");
        String clientSecret = System.getenv("PAYPAL_CLIENT_SECRET");
        String mode         = System.getenv().getOrDefault("PAYPAL_MODE", "sandbox");

        this.paypalServicio = new PayPalServicio(clientId, clientSecret, mode);
        this.httpClient     = HttpClient.newHttpClient();
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        // 1) Parsear JSON de petición { orderId, payerId }
        String jsonBody = new BufferedReader(req.getReader())
                .lines()
                .reduce("", (a,b) -> a + b);
        JSONObject body = new JSONObject(jsonBody);
        String orderId = body.getString("orderId");
        String payerId = body.getString("payerId");

        // 2) Capturar en PayPal
        Order capture;
        try {
            capture = paypalServicio.capturarOrden(orderId);
        } catch (IOException e) {
            resp.sendError(500, "Error al capturar orden en PayPal");
            return;
        }

        // 3) Actualizar donación en tu API
        JSONObject dto = new JSONObject();
        dto.put("orderId", orderId);
        dto.put("estado", "CAPTURED");
        dto.put("payerId", payerId);
        dto.put("payerEmail", capture.payer().email());
        dto.put("capturadoEn", Instant.now().toString());

        HttpRequest apiRequest = HttpRequest.newBuilder()
            .uri(URI.create("http://localhost:8080/api/donaciones"))
            .header("Content-Type", "application/json")
            .PUT(HttpRequest.BodyPublishers.ofString(dto.toString()))
            .build();

        try {
            httpClient.send(apiRequest, HttpResponse.BodyHandlers.discarding());
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            resp.sendError(500, "Error al actualizar donación");
            return;
        }

        // 4) Responder éxito
        resp.setContentType("application/json");
        resp.getWriter().write("{\"success\":true}");
    }
}
