package controladores;

import servicios.PayPalServicio;
import com.paypal.orders.Order;
import org.json.JSONObject;

import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.BufferedReader;
import java.io.IOException;
import java.math.BigDecimal;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;

/**
 * Servlet que:
 *  1) Crea una orden en PayPal.
 *  2) Persiste el registro de la donación en tu API externa.
 *  3) Devuelve al cliente el orderId para que PayPal renderice el botón.
 */
@WebServlet("/donar/crear")
public class CrearDonacionController extends HttpServlet {

    private PayPalServicio paypalServicio;
    private HttpClient httpClient;

    @Override
    public void init() {
        // Lee credenciales de entorno
        String clientId     = System.getenv("PAYPAL_CLIENT_ID");
        String clientSecret = System.getenv("PAYPAL_CLIENT_SECRET");
        String mode         = System.getenv().getOrDefault("PAYPAL_MODE", "sandbox");

        // Inicializa servicio y cliente HTTP
        this.paypalServicio = new PayPalServicio(clientId, clientSecret, mode);
        this.httpClient     = HttpClient.newHttpClient();
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        // 1) Parsear JSON de petición { importe, moneda }
        String jsonBody = new BufferedReader(req.getReader())
                .lines()
                .reduce("", (a,b) -> a + b);
        JSONObject body = new JSONObject(jsonBody);
        BigDecimal importe = new BigDecimal(body.getString("importe"));
        String moneda      = body.getString("moneda");

        // 2) Crear orden en PayPal
        String orderId = paypalServicio.crearOrden(importe, moneda);

        // 3) Guardar donación en tu API (DonacionDto)
        JSONObject dto = new JSONObject();
        dto.put("orderId", orderId);
        dto.put("importe", importe);
        dto.put("moneda", moneda);

        HttpRequest apiRequest = HttpRequest.newBuilder()
            .uri(URI.create("http://localhost:8080/api/donaciones"))
            .header("Content-Type", "application/json")
            .POST(HttpRequest.BodyPublishers.ofString(dto.toString()))
            .build();

        try {
            httpClient.send(apiRequest, HttpResponse.BodyHandlers.discarding());
        } catch (InterruptedException e) {
            // Manejo sencillo; en producción, haz retry o loguea
            Thread.currentThread().interrupt();
            resp.sendError(500, "Error al persistir donación");
            return;
        }

        // 4) Devolver orderId al frontend
        resp.setContentType("text/plain");
        resp.getWriter().write(orderId);
    }
}
